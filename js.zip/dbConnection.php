<?php
// Database connection settings
$host = '20.24.15.42';        // Database host (usually localhost)
$db_user = 'psmenow_natcon'; // Database username
$db_password = 'xqrZgkru4muD'; // Database password
$db_name = 'psmenow_natcon';  // Database name

// Create a new MySQLi connection
$db = new mysqli($host, $db_user, $db_password, $db_name);

// Check the connection
if ($db->connect_error) {
    die("Connection failed: " . $db->connect_error);
}

// Optionally, you can set the character set to UTF-8
$db->set_charset("utf8mb4");

// Now you can use $conn for any database queries
?>