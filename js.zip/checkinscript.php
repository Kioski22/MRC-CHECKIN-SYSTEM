<?php
session_start();
header('Content-Type: application/json');

include('dbConnection.php');

// Get the input data
$data = json_decode(file_get_contents('php://input'), true);

$firstname = $data['firstname'];
$lastname = $data['lastname'];
$middlename = $data['middlename'];
$email = $data['email'];
$prclicensenumber = $data['prclicensenumber'];
$chapter = $data['chapter'];
$qrcode = $data['qrcode'];

// Insert the check-in record
$sql = "INSERT INTO checkins (firstname, lastname, middlename, email, prclicensenumber, chapter, qrcode) VALUES (?, ?, ?, ?, ?, ?, ?)";
$stmt = $db->prepare($sql);
$stmt->bind_param("sssssss", $firstname, $lastname, $middlename, $email, $prclicensenumber, $chapter, $qrcode);

if ($stmt->execute()) {
    $response = ['success' => true, 'message' => 'Check-in successful!'];
} else {
    $response = ['success' => false, 'message' => 'Check-in failed: ' . $stmt->error];
}

$stmt->close();
$db->close();

echo json_encode($response);
?>
