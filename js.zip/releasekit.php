<?php
session_start();
header('Content-Type: application/json');

include('dbconnection.php');

// Get the input data
$data = json_decode(file_get_contents('php://input'), true);

$qrcode = $data['qrcode'];

// Check if the kit is already released
$sql = "SELECT kit_released, kit_release_time FROM checkins WHERE qrcode = ?";
$stmt = $db->prepare($sql);
$stmt->bind_param("s", $qrcode);
$stmt->execute();
$stmt->bind_result($kit_released, $kit_release_time);
$stmt->fetch();
$stmt->close();

if ($kit_released) {
    $response = [
        'success' => false,
        'message' => 'Kit already released',
        'releaseTime' => $kit_release_time
    ];
} else {
    // Update the record to mark the kit as released
    $release_time = date('Y-m-d H:i:s');
    $sql = "UPDATE checkins SET kit_released = 1, kit_release_time = ? WHERE qrcode = ?";
    $stmt = $db->prepare($sql);
    $stmt->bind_param("ss", $release_time, $qrcode);

    if ($stmt->execute()) {
        $response = [
            'success' => true,
            'message' => 'Kit released successfully!',
            'releaseTime' => $release_time
        ];
    } else {
        $response = ['success' => false, 'message' => 'Kit release failed: ' . $stmt->error];
    }

    $stmt->close();
}

$db->close();

echo json_encode($response);
?>
