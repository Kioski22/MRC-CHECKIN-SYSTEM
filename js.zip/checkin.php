<?php
session_start();
if (!isset($_SESSION['access_token'])) {
    header("Location: login2.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Check In</title>

    <!-- Custom fonts for this template-->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="css/sb-admin-2.min.css" rel="stylesheet">
    <script src="js\html5-qrcode.min.js"></script>
</head>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
        <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

            <!-- Sidebar - Brand -->
            <a class="sidebar-brand d-flex align-items-center justify-content-center" href="dashboard2.php">
                <div class="sidebar-brand-icon rotate-n-15">
                    <i class="fas fa-laugh-wink"></i>
                </div>
                <div class="sidebar-brand-text mx-3">PSME ICTO</div>
            </a>

            <!-- Divider -->
            <hr class="sidebar-divider my-0">

            <!-- Nav Item - Dashboard -->
            <li class="nav-item active">
                <a class="nav-link" href="dashboard2.php">
                    <i class="fas fa-fw fa-camera"></i>
                    <span>Scan</span></a>
            </li>

            <!-- Divider -->
            <hr class="sidebar-divider">

            <!-- Heading -->
            <div class="sidebar-heading">
                Interface
            </div>

            <!-- Nav Item - Pages Collapse Menu -->
            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseTwo"
                    aria-expanded="true" aria-controls="collapseTwo">
                    <i class="fas fa-fw fa-cog"></i>
                    <span>Components</span>
                </a>
                <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <h6 class="collapse-header">Custom Components:</h6>
                        <a class="collapse-item" href="buttons.html">Buttons</a>
                        <a class="collapse-item" href="cards.html">Cards</a>
                    </div>
                </div>
            </li>

            <!-- Nav Item - Utilities Collapse Menu -->
            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseUtilities"
                    aria-expanded="true" aria-controls="collapseUtilities">
                    <i class="fas fa-fw fa-wrench"></i>
                    <span>Utilities</span>
                </a>
                <div id="collapseUtilities" class="collapse" aria-labelledby="headingUtilities"
                    data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <h6 class="collapse-header">Custom Utilities:</h6>
                        <a class="collapse-item" href="utilities-color.html">Colors</a>
                        <a class="collapse-item" href="utilities-border.html">Borders</a>
                        <a class="collapse-item" href="utilities-animation.html">Animations</a>
                        <a class="collapse-item" href="utilities-other.html">Other</a>
                    </div>
                </div>
            </li>

            <!-- Divider -->
            <hr class="sidebar-divider">

            <!-- Heading -->
            <div class="sidebar-heading">
                Addons
            </div>

            <!-- Nav Item - Pages Collapse Menu -->
            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapsePages"
                    aria-expanded="true" aria-controls="collapsePages">
                    <i class="fas fa-fw fa-folder"></i>
                    <span>Pages</span>
                </a>
                <div id="collapsePages" class="collapse" aria-labelledby="headingPages" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <h6 class="collapse-header">Login Screens:</h6>
                        <a class="collapse-item" href="login.html">Login</a>
                        <a class="collapse-item" href="register.html">Register</a>
                        <a class="collapse-item" href="forgot-password.html">Forgot Password</a>
                        <div class="collapse-divider"></div>
                        <h6 class="collapse-header">Other Pages:</h6>
                        <a class="collapse-item" href="404.html">404 Page</a>
                        <a class="collapse-item" href="blank.html">Blank Page</a>
                    </div>
                </div>
            </li>

            <!-- Nav Item - Charts -->
            <li class="nav-item">
                <a class="nav-link" href="charts.html">
                    <i class="fas fa-fw fa-chart-area"></i>
                    <span>Charts</span></a>
            </li>

            <!-- Nav Item - Tables -->
            <li class="nav-item">
                <a class="nav-link" href="tables.html">
                    <i class="fas fa-fw fa-table"></i>
                    <span>Tables</span></a>
            </li>

            <!-- Divider -->
            <hr class="sidebar-divider d-none d-md-block">

            <!-- Sidebar Toggler (Sidebar) -->
            <div class="text-center d-none d-md-inline">
                <button class="rounded-circle border-0" id="sidebarToggle"></button>
            </div>

        </ul>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

                    <!-- Sidebar Toggle (Topbar) -->
                    <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
                        <i class="fa fa-bars"></i>
                    </button>

                    <!-- Topbar Navbar -->
                    <ul class="navbar-nav ml-auto">

                        <div class="topbar-divider d-none d-sm-block"></div>

                        <!-- Nav Item - User Information -->
                        <li class="nav-item dropdown no-arrow">
                            <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <span class="mr-2 d-none d-lg-inline text-gray-600 small">Douglas McGee</span>
                                <img class="img-profile rounded-circle"
                                    src="img/undraw_profile.svg">
                            </a>
                            <!-- Dropdown - User Information -->
                            <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in"
                                aria-labelledby="userDropdown">
                                <a class="dropdown-item" href="#">
                                    <i class="fas fa-user fa-sm fa-fw mr-2 text-gray-400"></i>
                                    Profile
                                </a>
                                <a class="dropdown-item" href="#">
                                    <i class="fas fa-cogs fa-sm fa-fw mr-2 text-gray-400"></i>
                                    Settings
                                </a>
                                <a class="dropdown-item" href="#">
                                    <i class="fas fa-list fa-sm fa-fw mr-2 text-gray-400"></i>
                                    Activity Log
                                </a>
                                <div class="dropdown-divider"></div>
                                <a class="dropdown-item" href="" data-toggle="modal" data-target="#logoutModal">
                                    <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                                    Logout
                                </a>
                            </div>
                        </li>

                    </ul>

                </nav>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <div class="d-sm-flex align-items-center justify-content-between mb-4">
                        <h1 class="h3 mb-0 text-gray-800">Scan</h1>
                    </div>

                    <div class="row">

                        <div class="col-lg-12">

                            <!-- Dropdown for Scan Method -->
                            <div class="card shadow mb-4">
                                <div class="card-header py-3">
                                    <h6 class="m-0 font-weight-bold text-primary">Choose Scan Method</h6>
                                </div>
                                <div class="card-body">
                                    <label for="scanMethod">Choose Scan Method:</label>
                                    <select id="scanMethod" class="form-control">
                                        <option value="" disabled selected>Select a method</option>
                                        <option value="html5qr">Html5-QRCode</option>
                                        <option value="physical">Physical QR Code Scanner</option>
                                    </select>

                                    <div id="html5qr-reader" style="width: 100%; display: none;" class="mt-3"></div>
                                    <input type="text" id="physicalScannerInput" style="display: none;" class="form-control mt-3" placeholder="Scan QR code here">
                                    <p id="result" class="mt-3"></p>
                                </div>
                            </div>

                        </div>

                    </div>

                    <!-- Modal -->
                    <div class="modal fade" id="scanResultModal" tabindex="-1" role="dialog" aria-labelledby="scanResultModalLabel" aria-hidden="true">
                        <div class="modal-dialog" role="document">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="scanResultModalLabel">Scan Result</h5>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">×</span>
                                    </button>
                                </div>
                                <div class="modal-body">
                                    <p><strong>First Name:</strong> <span id="modalFirstname"></span></p>
                                    <p><strong>Last Name:</strong> <span id="modalLastname"></span></p>
                                    <p><strong>Middle Name:</strong> <span id="modalMiddlename"></span></p>
                                    <p><strong>Email:</strong> <span id="modalEmail"></span></p>
                                    <p><strong>PRC License Number:</strong> <span id="modalPrclicensenumber"></span></p>
                                    <p><strong>Chapter:</strong> <span id="modalChapter"></span></p>
                                    <p><strong>QR Code:</strong> <a id="modalQrcodeLink" href="" target="_blank">QR Code</a></p>
                                    <p id="kitReleaseStatus"></p>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                    <button type="button" class="btn btn-primary" onclick="printLabel()">Print</button>
                                    <button type="button" class="btn btn-success" onclick="checkIn()">Check In</button>
                                    <button type="button" class="btn btn-warning" onclick="releaseKit()">Release Kit</button>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>

                <!-- Check-In and Release Kit Result Modal -->
                <div class="modal fade" id="checkinResultModal" tabindex="-1" role="dialog" aria-labelledby="checkinResultModalLabel" aria-hidden="true">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="checkinResultModalLabel">Result</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">×</span>
                                </button>
                            </div>
                            <div class="modal-body">
                                <p id="checkinResultMessage"></p>
                                <p id="kitReleaseStatus"></p>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                            </div>
                        </div>
                    </div>
                </div>


                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->

            <!-- Footer -->
            <footer class="sticky-footer bg-white">
                <div class="container my-auto">
                    <div class="copyright text-center my-auto">
                        <span>Copyright &copy; PSME ICTO 2024</span>
                    </div>
                </div>
            </footer>
            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <!-- Logout Modal-->
    <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
                <div class="modal-footer">
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                    <a class="btn btn-primary" href="logout.php">Logout</a>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin-2.min.js"></script>

    <script>
        document.getElementById('scanMethod').addEventListener('change', function() {
            const method = this.value;
            if (method === 'html5qr') {
                document.getElementById('html5qr-reader').style.display = 'block';
                document.getElementById('physicalScannerInput').style.display = 'none';
                startHtml5QrCodeScanner();
            } else {
                document.getElementById('html5qr-reader').style.display = 'none';
                document.getElementById('physicalScannerInput').style.display = 'block';
                startPhysicalScanner();
            }
        });

        function startHtml5QrCodeScanner() {
            let html5QrcodeScanner = new Html5QrcodeScanner(
                "html5qr-reader", {
                    fps: 10,
                    qrbox: 250
                });
            html5QrcodeScanner.render(onScanSuccess, onScanFailure);
        }

        function onScanSuccess(decodedText, decodedResult) {
            document.getElementById('result').innerText = `Scanned result: ${decodedText}`;
            makeApiRequest(decodedText);
        }

        function onScanFailure(error) {
            console.warn(`QR error = ${error}`);
        }

        function startPhysicalScanner() {
            const input = document.getElementById('physicalScannerInput');
            input.focus();

            let debounceTimeout;
            input.addEventListener('input', function() {
                clearTimeout(debounceTimeout);
                debounceTimeout = setTimeout(() => {
                    const scannedValue = input.value;
                    console.log(`Scanned result: ${scannedValue}`);
                    document.getElementById('result').innerText = `Scanned result: ${scannedValue}`;
                    makeApiRequest(scannedValue);
                    input.value = ''; // Clear the input field
                }, 300); // Adjust the debounce delay as needed
            });
        }

        function makeApiRequest(scannedValue) {
            fetch(`https://psme-api.smartpay.ph/public/index.php/api/getScanData?scan=${scannedValue}`, {
                    method: 'GET',
                    headers: {
                        'Authorization': 'Bearer <?php echo $_SESSION['access_token']; ?>'
                    }
                })
                .then(response => response.json())
                .then(data => {
                    console.log(data);
                    if (data.resultValue && data.resultValue.length > 0) {
                        const result = data.resultValue[0];
                        document.getElementById('modalFirstname').innerText = result.firstname;
                        document.getElementById('modalLastname').innerText = result.lastname;
                        document.getElementById('modalMiddlename').innerText = result.middlename;
                        document.getElementById('modalEmail').innerText = result.email;
                        document.getElementById('modalPrclicensenumber').innerText = result.prclicensenumber;
                        document.getElementById('modalChapter').innerText = result.chapter;
                        document.getElementById('modalQrcodeLink').href = result.qrcode;

                        // Check if the kit is already released
                        if (result.kit_released) {
                            const releaseTime = new Date(result.kit_release_time).toLocaleString('en-PH', {
                                timeZone: 'Asia/Manila'
                            });
                            document.getElementById('kitReleaseStatus').innerText = `Kit released at: ${releaseTime}`;
                        } else {
                            document.getElementById('kitReleaseStatus').innerText = 'Kit not released yet';
                        }

                        // Show the modal
                        $('#scanResultModal').modal('show');
                    } else {
                        document.getElementById('result').innerText += `\nError: ${data.errorMsg || 'Unknown error'}`;
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    document.getElementById('result').innerText += `\nError: ${error.message}`;
                });
        }

        function printLabel() {
            const firstname = document.getElementById('modalFirstname').innerText;
            const lastname = document.getElementById('modalLastname').innerText;
            const middlename = document.getElementById('modalMiddlename').innerText;
            const chapter = document.getElementById('modalChapter').innerText;
            const qrcodeLink = document.getElementById('modalQrcodeLink').href;

            const printContent = `
        <div style="width: 50mm; height: 40mm; display: flex; flex-direction: column; justify-content: center; align-items: center; font-size: 13px; text-align: center; line-height: 1; margin: 0; font-weight: bold;">
            <p style="margin: 0;"><strong>${lastname},</strong></p>
            <p style="margin: 0;"><strong>${firstname} ${middlename}</strong></p>    
            <img src="${qrcodeLink}" alt="QR Code" style="width: 25mm; height: 25mm;" onload="window.print()">
            <p style="margin: 0;"><strong>${chapter}</strong></p>
        </div>
    `;

            const printWindow = window.open('', '', 'height=400,width=600');
            printWindow.document.write('<html><head><title>Print Label</title></head><body style="margin: 0; padding: 0; font-family: Tahoma, sans-serif;">');
            printWindow.document.write(printContent);
            printWindow.document.write('</body></html>');
            printWindow.document.close();
            printWindow.onload = function() {
                printWindow.print();
                printWindow.close();
            };
        }

        function checkIn() {
            const firstname = document.getElementById('modalFirstname').innerText;
            const lastname = document.getElementById('modalLastname').innerText;
            const middlename = document.getElementById('modalMiddlename').innerText;
            const email = document.getElementById('modalEmail').innerText;
            const prclicensenumber = document.getElementById('modalPrclicensenumber').innerText;
            const chapter = document.getElementById('modalChapter').innerText;
            const qrcode = document.getElementById('modalQrcodeLink').href;

            fetch('checkinscript.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({
                        firstname,
                        lastname,
                        middlename,
                        email,
                        prclicensenumber,
                        chapter,
                        qrcode
                    })
                })
                .then(response => response.json())
                .then(data => {
                    document.getElementById('checkinResultMessage').innerText = data.message;
                    $('#checkinResultModal').modal('show');
                    if (data.success) {
                        const releaseKitNow = confirm('Do you want to release the kit now?');
                        if (releaseKitNow) {
                            releaseKitFunction(qrcode);
                        }
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    document.getElementById('checkinResultMessage').innerText = 'Check-in failed: ' + error.message;
                    $('#checkinResultModal').modal('show');
                });
        }

        function releaseKitFunction(qrcode) {
            fetch('releaseKit.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({
                        qrcode
                    })
                })
                .then(response => response.json())
                .then(data => {
                    document.getElementById('checkinResultMessage').innerText = data.message;
                    if (data.success) {
                        const releaseTime = new Date(data.releaseTime).toLocaleString('en-PH', {
                            timeZone: 'Asia/Manila'
                        });
                        document.getElementById('kitReleaseStatus').innerText = `Kit released at: ${releaseTime}`;
                    }
                    $('#checkinResultModal').modal('show');
                })
                .catch(error => {
                    console.error('Error:', error);
                    document.getElementById('checkinResultMessage').innerText = 'Kit release failed: ' + error.message;
                    $('#checkinResultModal').modal('show');
                });
        }


        function releaseKit() {
            const qrcode = document.getElementById('modalQrcodeLink').href;
            releaseKitFunction(qrcode);
        }
    </script>

    <script>
        feather.replace();
    </script>
</body>

</html>